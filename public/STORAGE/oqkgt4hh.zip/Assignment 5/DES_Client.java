//Name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

class client{
	public static void main(String args[]) throws Exception
	{
		try{
			Socket socket =new Socket("localhost",6363);
			DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
			DataInputStream inStream = new DataInputStream(socket.getInputStream());
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter msg:");
			String msg=sc.nextLine();
			//Generate random key

			//keyGenerator kg=keyGenerator.getInstance("DES");
			//Secretkey key=kg.generatekey();

			//define key
			String keystring="kssbmdcn";
			SecretKey key=new SecretKeySpec(keystring.getBytes(),"DES");

			//instantiate 

			Cipher cipher=Cipher.getInstance("DES/ECB/PKCS5padding");
			//initialize cipher object

			cipher.init(Cipher.ENCRYPT_MODE,key);


			//perform the encryption

			byte ctByte[]=cipher.doFinal(msg.getBytes());
			String ctString = new String(ctByte);
			System.out.println("Send Encrypted data :"+ctString);
			outStream.writeUTF(ctString);
			String ctString1=inStream.readUTF();
			System.out.println("received Dycrypted data :"+ctString1);
			outStream.flush();
			outStream.close();
			socket.close();


			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}