//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class sender
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds = new DatagramSocket();
				String msg=new String();
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter your message: ");
				String msg1=new String();
				msg1=sc.nextLine();
					String r1="";
					String r2="";
					for(int i=0;i<msg1.length();i++)
					{
						if(i%2==0)
							r1+=msg1.charAt(i);
						else
							r2+=msg1.charAt(i);
					}
					String c_msg="";
					c_msg=r1+r2;
					System.out.println("send Cipher Message ="+c_msg);
				InetAddress ip=InetAddress.getByName("localhost");
				DatagramPacket dp=new DatagramPacket(c_msg.getBytes(),c_msg.length(),ip,6565);
				ds.send(dp);
				ds.close();



				DatagramSocket ds1= new DatagramSocket(6566);
				
				byte[] buf =new byte[1024];
				DatagramPacket dp1=new DatagramPacket(buf,1024);
				ds1.receive(dp1);
					 msg= new String(dp1.getData(),0,dp1.getLength());
				System.out.println("Receive Original Message  :"+msg);
					ds1.close();

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

