//Name:Chunara Jahanvi ,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class client{
	public static void main(String args[]) throws Exception
	{
		try{
			Socket socket =new Socket("localhost",6363);
			DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
			DataInputStream inStream = new DataInputStream(socket.getInputStream());
			String data="abcdefghijklmnopqrstuvwxyz";
				String key="qwertyuiopasdfghjklzxcvbnm";
				String msg=new String();
				String msg1=new String();
				String d_msg=new String();
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter your message: ");
				msg=sc.nextLine();
				int index=0;
				
				int len=msg.length();
				int len1=data.length();
				for(int i=0;i<len;i++)
				{
					index=data.indexOf(msg.charAt(i));
					msg1+=key.charAt(index);
				}
				System.out.println("Encryption:\nOrignal message="+msg);
				System.out.println("Send Cipher Text="+msg1);
			outStream.writeUTF(msg1);
			String rec_msg=inStream.readUTF();
			System.out.println("Receive Original Message="+rec_msg);
			outStream.flush();
			outStream.close();
			socket.close();


			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}