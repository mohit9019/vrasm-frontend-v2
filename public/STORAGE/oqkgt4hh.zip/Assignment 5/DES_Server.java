//Name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

class server{
	public static void main(String args[]) throws Exception
	{
	try{
		ServerSocket serversocket = new ServerSocket(6363);

		System.out.println("server is listening on localost :6363");
		Socket socket =serversocket.accept();
		DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
		DataInputStream inStream = new DataInputStream(socket.getInputStream());
		//define key
			String keystring="kssbmdcn";
			SecretKey key=new SecretKeySpec(keystring.getBytes(),"DES");

			//instantiate 

			Cipher cipher=Cipher.getInstance("DES/ECB/PKCS5padding");
		String ctString=inStream.readUTF();
		System.out.println("Received Encrypted Data:"+ctString);
		cipher.init(Cipher.DECRYPT_MODE,key);


			//perform the encryption

			byte ptByte[]=cipher.doFinal(ctString.getBytes());
			String ptString = new String(ptByte);
			System.out.println(" send Decrypted data:"+ptString);
				outStream.writeUTF(ptString);
		inStream.close();
		socket.close();
		serversocket.close();

	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
