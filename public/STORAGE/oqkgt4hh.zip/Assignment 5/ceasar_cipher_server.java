//Name:Chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;

class server{
	public static void main(String args[]) throws Exception
	{
	try{
		ServerSocket serversocket = new ServerSocket(6363);
		System.out.println("server is listening on localost :6363");
		Socket socket =serversocket.accept();
		DataInputStream inStream = new DataInputStream(socket.getInputStream());
		DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
		String msg1=inStream.readUTF();
		String msg2="";
		int key=2;
		for(int i=0; i<msg1.length(); i++)
				{
				  int asciiValue = msg1.charAt(i);
				  //System.out.println(asciiValue);

				 int index=(((asciiValue-key)-97)%26)+97;
				  //System.out.println("\n index="+index);
				  
					 msg2+=Character.toString((char) index);
				//System.out.println("message="+msg2);
				  
				}
				System.out.println("\nDecryption:\nReceiving message="+msg1);
				System.out.println("Send Original message="+msg2);
					outStream.writeUTF(msg2);
		//System.out.println(msg);
		inStream.close();
		outStream.flush();
			outStream.close();
			
		socket.close();
		serversocket.close();

	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
