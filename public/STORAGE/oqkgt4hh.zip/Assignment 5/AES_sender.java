//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

class sender
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds = new DatagramSocket();
				Scanner sc=new Scanner(System.in);
			System.out.println("Enter msg:");
			String msg=sc.nextLine();
			//Generate random key

			//keyGenerator kg=keyGenerator.getInstance("DES");
			//Secretkey key=kg.generatekey();

			//define key
			String keystring="kssbmdcnkssbmdcn";
			SecretKey key=new SecretKeySpec(keystring.getBytes(),"AES");

			//instantiate 

			Cipher cipher=Cipher.getInstance("AES/ECB/PKCS5padding");
			//initialize cipher object

			cipher.init(Cipher.ENCRYPT_MODE,key);


			//perform the encryption

			byte ctByte[]=cipher.doFinal(msg.getBytes());
			String ctString = new String(ctByte);
			System.out.println("Send Encrypted data:"+ctString);
				InetAddress ip=InetAddress.getByName("localhost");
				DatagramPacket dp=new DatagramPacket(ctString.getBytes(),ctString.length(),ip,6565);
				ds.send(dp);
				ds.close();



				DatagramSocket ds1= new DatagramSocket(6566);
				
				byte[] buf =new byte[1024];
				DatagramPacket dp1=new DatagramPacket(buf,1024);
				ds1.receive(dp1);

					 msg= new String(dp1.getData(),0,dp1.getLength());
				System.out.println("Receive Original msg:"+msg);
					ds1.close();

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

