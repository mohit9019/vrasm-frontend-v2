//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class sender
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds = new DatagramSocket();
				
				//Scanner sc=new Scanner(System.in);
				String data=new String();
				String key=new String();
				//int key=2;
				String c_msg="";
				String d_msg="";
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter your message: ");
				data=sc.nextLine();
				System.out.println("Enter your key: ");
				key=sc.nextLine();

				int i=0;
				while(key.length()<data.length())
				{
					key+=key.charAt(i);
					i++;
				}
				System.out.println(" New key:"+key);
					for(i=0;i<data.length();i++)
					{
						int index=(data.charAt(i)-97 + key.charAt(i)-97)%26;
						index+=97;
						c_msg+=(char)index;
					}
				System.out.println("Send Cipher Message:"+c_msg);
				String s_msg="";
				s_msg=key+c_msg;

				InetAddress ip=InetAddress.getByName("localhost");
				DatagramPacket dp=new DatagramPacket(s_msg.getBytes(),s_msg.length(),ip,6565);
				ds.send(dp);
				ds.close();



				DatagramSocket ds1= new DatagramSocket(6566);
				
				byte[] buf =new byte[1024];
				DatagramPacket dp1=new DatagramPacket(buf,1024);
				ds1.receive(dp1);
				String msg="";
					 msg= new String(dp1.getData(),0,dp1.getLength());
				System.out.println("Receive Original Message  :"+msg);
					ds1.close();

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

