//Name:Chunara Jahanvi ,Roll_no:3087
import java.io.*;
import java.net.*;

class server{
	public static void main(String args[]) throws Exception
	{
	try{
		ServerSocket serversocket = new ServerSocket(6363);
		System.out.println("server is listening on localost :6363");
		Socket socket =serversocket.accept();
		DataInputStream inStream = new DataInputStream(socket.getInputStream());
		DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
		String msg1=inStream.readUTF();
		String data="abcdefghijklmnopqrstuvwxyz";
				String key="qwertyuiopasdfghjklzxcvbnm";
				int len=msg1.length();
				//int len1=data.length();
				String d_msg=new String();
		for(int i=0;i<len;i++)
				{
					int index=key.indexOf(msg1.charAt(i));
					d_msg+=data.charAt(index);
				}
				System.out.println("\nDecryption:\nReceiving message="+msg1);
				System.out.println("Send Original message="+d_msg);
					outStream.writeUTF(d_msg);
		//System.out.println(msg);
		inStream.close();
		outStream.flush();
			outStream.close();
			
		socket.close();
		serversocket.close();

	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
