//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class receiver
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds= new DatagramSocket(6565);
				Scanner sc=new Scanner(System.in);
				//System.out.println("server is listening on localost :6363");
				byte[] buf =new byte[1024];
				DatagramPacket dp=new DatagramPacket(buf,1024);
				ds.receive(dp);
				String msg= new String(dp.getData(),0,dp.getLength());
				System.out.println("Receive Cipher Message:"+msg);
				String key="";
				key=msg.substring(0,msg.length()/2);
				String c_msg="";
				c_msg=msg.substring(msg.length()/2,msg.length());
					System.out.println("key:"+key);
				String d_msg="";
				int i=0;
			for(i=0;i<c_msg.length();i++)
					{
						 int index=((c_msg.charAt(i)-97) - (key.charAt(i)-97)+26)%26;
						index+=97;
						//System.out.println("index="+index);

						d_msg+=(char)index;
					}
				System.out.println("Send De_Cipher Message:"+d_msg);
					ds.close();

				DatagramSocket ds1 = new DatagramSocket();
				
				
				InetAddress ip1=InetAddress.getByName("localhost");
				DatagramPacket dp1=new DatagramPacket(d_msg.getBytes(),d_msg.length(),ip1,6566);
				ds1.send(dp1);
				ds1.close();
				
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}