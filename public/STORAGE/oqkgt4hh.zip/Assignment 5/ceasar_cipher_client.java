//Name:Chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class client{
	public static void main(String args[]) throws Exception
	{
		try{
			Socket socket =new Socket("localhost",6363);
			DataOutputStream outStream =new DataOutputStream(socket.getOutputStream());
			DataInputStream inStream = new DataInputStream(socket.getInputStream());
		
				String data="abcdefghijklmnopqrstuvwxyz";
		
				
				String msg=new String();
				String msg1=new String();
				String msg2=new String();
				String d_msg=new String();
				int index=0;
				int key=2;
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter your message: ");
				msg=sc.nextLine();
				for(int i=0; i<msg.length(); i++)
				{
				  int asciiValue = msg.charAt(i);
				 // System.out.println(asciiValue);

				  index=(((asciiValue+key)-97)%26)+97;
		
				  
					 msg1+=Character.toString((char) index);
				
				  
				}
				System.out.println("Encryption:\nOrignal message="+msg);
				System.out.println("Send Cipher Text="+msg1);
			outStream.writeUTF(msg1);
			String rec_msg=inStream.readUTF();
			System.out.println("Receive Original Message="+rec_msg);
			outStream.flush();
			outStream.close();
			socket.close();


			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}