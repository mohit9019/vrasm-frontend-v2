//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
class receiver
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds= new DatagramSocket(6565);
				Scanner sc=new Scanner(System.in);
				//System.out.println("server is listening on localost :6363");
				byte[] buf =new byte[1024];
				DatagramPacket dp=new DatagramPacket(buf,1024);
				ds.receive(dp);
				String c_msg= new String(dp.getData(),0,dp.getLength());
				System.out.println("Receive Cipher Message="+c_msg);
				String str1="";
						String str2="";
					if(c_msg.length()%2==0)
					{
						str1=c_msg.substring(0,c_msg.length()/2);
						str2=c_msg.substring(c_msg.length()/2,c_msg.length());
					}
					else
					{
						str1=c_msg.substring(0,c_msg.length()/2+1);
						str2=c_msg.substring(c_msg.length()/2+1,c_msg.length());
					}

					String d_msg="";
					for (int i=0,x=0,y=0;i<c_msg.length() ;i++) {
						if(i%2==0)
						{
							d_msg+=str1.charAt(x);
							x++;
						}

						else
						{
							d_msg+=str2.charAt(y);
							y++;
						}
					}


					System.out.println("send D-Cipher Message="+d_msg);
					ds.close();

				DatagramSocket ds1 = new DatagramSocket();
				
				
				InetAddress ip1=InetAddress.getByName("localhost");
				DatagramPacket dp1=new DatagramPacket(d_msg.getBytes(),d_msg.length(),ip1,6566);
				ds1.send(dp1);
				ds1.close();
				
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}