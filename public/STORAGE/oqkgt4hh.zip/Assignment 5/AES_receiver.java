//name:chunara jahanvi,Roll_no:3087
import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

class receiver
{
	public static void main(String args[]) throws Exception
	{
		try
		{
				DatagramSocket ds= new DatagramSocket(6565);
				
				//System.out.println("server is listening on localost :6363");
				byte[] buf =new byte[1024];
				DatagramPacket dp=new DatagramPacket(buf,1024);
				ds.receive(dp);
				String ctString= new String(dp.getData(),0,dp.getLength());
				System.out.println("Receive Encrypted data:"+ctString);
				//define key
			String keystring="kssbmdcnkssbmdcn";
			SecretKey key=new SecretKeySpec(keystring.getBytes(),"AES");

			//instantiate 

			Cipher cipher=Cipher.getInstance("AES/ECB/PKCS5padding");
				cipher.init(Cipher.DECRYPT_MODE,key);


			//perform the encryption

			byte ptByte[]=cipher.doFinal(ctString.getBytes());
			String ptString = new String(ptByte);
			System.out.println("Decrypted data:"+ptString);
					ds.close();

				DatagramSocket ds1 = new DatagramSocket();
			
				InetAddress ip1=InetAddress.getByName("localhost");
				DatagramPacket dp1=new DatagramPacket(ptString.getBytes(),ptString.length(),ip1,6566);
				ds1.send(dp1);
				ds1.close();
				
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}