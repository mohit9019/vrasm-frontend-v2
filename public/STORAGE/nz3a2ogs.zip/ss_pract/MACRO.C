#include<stdio.h>
#include<conio.h>
#include<string.h>
struct mnt1
{
 char name[15];
 int npp,nkp,nev,mdtp,kpdtp,sstp;
}mnt;
struct ktb
{
 int addr;
 char pnm[15],dnm[15];
}kpdtab[5];
/*struct mt
{
 int addr;
 char lbl[15],opcode[5],oprand[5][5];
}mdt[10];*/

void main()
{
FILE *f1;
char ch[80],*p,pntab[5][10],evntab[5][10],ssntab[10][10];
int i,j,sstab[5];
char *ptr,tmp[10];
int pntbptr = 0,ktbptr = 10,mdtptr = 25,sstbptr = 0,ssntbptr = 0,evtbptr=0;
mnt.npp=mnt.nkp=mnt.nev=0;
mnt.mdtp=25;
mnt.kpdtp=10;
mnt.sstp=5;
clrscr();
f1 = fopen("c:\\tc\\bin\\msource.txt","r");
 fgets(ch,80,f1);
 p = strtok(ch," ");
 if(p[strlen(p)-1] == '\n')
	 p[strlen(p)-1] = NULL;
 puts(p);
 if(strcmp(p,"MACRO")==0)
   {
     fgets(ch,80,f1);
     p = strtok(ch," ");
     strcpy(mnt.name,p);
     p = strtok(NULL," ");
     while(p)
     {
      if(p[strlen(p)-1] == '\n')
	 p[strlen(p)-1] = NULL;

      if(p[strlen(p)-1] == ',')
	 p[strlen(p)-1] = NULL;
      ptr = strchr(p,'=');
      if (ptr)
       {
	 for(i=0;i<ptr-p;i++)
	     {

	       kpdtab[ktbptr].pnm[i] = p[i];
	       pntab[pntbptr][i] = p[i];
	     }
	       kpdtab[ktbptr].pnm[i] = NULL;
	       pntab[pntbptr][i] = NULL;

	     pntbptr++;
	 for(i=ptr-p+1,j=0;i<strlen(p);i++,j++)
	       kpdtab[ktbptr].dnm[j] = p[i];
	       kpdtab[ktbptr].dnm[j] = NULL;
	     ktbptr++;
	    mnt.nkp++;
       }
       else
	       {
		strcpy(pntab[pntbptr],p);
		pntbptr++;
		mnt.npp++;
	       }
		p = strtok(NULL," ");
     }

      while(!feof(f1))
       {       fgets(ch,80,f1);
	       p = strtok(ch," ");
	       printf("\n %d |",mdtptr);
	       while(p)
		 {
		  if(p[strlen(p)-1] == '\n')
		     p[strlen(p)-1] = NULL;

		   if((strcmp(p,"LCL")==0))
		      {   printf(" %s ",p);
			   p =strtok(NULL," ");
			  if(p[strlen(p)-1] == '\n')
			     p[strlen(p)-1] = NULL;
			   strcpy(evntab[evtbptr],p);
			   printf("(E,%d) ",evtbptr+1);
			   evtbptr++;
			   mnt.nev++;
			   break;
		      }
		    else
		    if(p[0] == '.')
		       {
			 for(i=0;i<ssntbptr;i++)
			    {
			      if(strcmp(p,ssntab[i])==0)
				 {
				  printf("(S,%d) ",i+1);
				  break;
				  }
			    }
			  if(i==ssntbptr)
			     {
				strcpy(ssntab[ssntbptr],p);
				ssntbptr++;
				sstab[mnt.sstp + sstbptr] = mdtptr;
				sstbptr++;
			     }
		       }
		     else
		     if(strcmp(p,"SET")==0)
		       {
			for(i=0;i<evtbptr;i++)
			    {
			      if(strcmp(evntab[i],tmp)==0)
				 {
				  printf("SET ",i+1);
				  break;
				 }
			    }
		       }
		   else
		    if(p[0] == '&')
		      {
			for(i=0;i<evtbptr;i++)
			    {
			      if(strcmp(evntab[i],p)==0)
				 {
				  printf("(E,%d) ",i+1);
				  break;
				 }
			    }
			for(i=0;i<pntbptr;i++)
			    {
			      if(strcmp(pntab[i],p)==0)
				 {
				  printf("(P,%d) ",i+1);
				  break;
				 }
			    }

		      }
		   else
			   printf(" %s ",p);
		   strcpy(tmp,p);
		   p =strtok(NULL," ");
		}
		mdtptr++;
       }
       getch();
       printf("\n\tPntab\n");
       for(i=0;i<pntbptr;i++)
	    {printf("\t ");
	    puts(pntab[i]);
	    }
       printf("\t\tEvntab\n\t\t  ");
       for(i=0;i<evtbptr;i++)
	    puts(evntab[i]);
       printf("\t\t\tSsntab\n");
       for(i=0;i<ssntbptr;i++)
	  {printf("\t\t\t");
	    puts(ssntab[i]);}

       printf("\t\t  MNT\n");
       printf("-------------------------------------------\n");
       printf("  Name     #pp  #kp  #ev  MDTP  KPDTP  SSTP\n");
       printf("%s    %d    %d    %d    %d    %d     %d",mnt.name,mnt.npp,mnt.nkp,mnt.nev,mnt.mdtp,mnt.kpdtp,mnt.sstp);
       printf("\n-------------------------------------------\n");
       printf("\n\t\tKpdtab\n");
       for(i=mnt.kpdtp;i<ktbptr;i++)
	    printf("\t%d | %s   %s |\n",i,kpdtab[i].pnm,kpdtab[i].dnm);
       printf("\n\t\tSstab\n");
       for(i=mnt.sstp;i<mnt.sstp+sstbptr;i++)
	    printf("\t\t%d | %d\n",i,sstab[i]);

  }
 else
    printf("Invalid sourse...");
getch();
}
/*
output:
MACRO

 25 | LCL (E,1)
 26 |(E,1) SET  0
 27 | MOVER (P,3)  ,  ='0'
 28 | MOVEM (P,3)  , (P,1)  + (E,1)
 29 |(E,1) SET (E,1)  +  1
 30 | AIF  ( (E,1)  NE (P,2)  ) (S,1)
 31 | MEND
	Pntab
	 &X
	 &N
	 &REG
		Evntab
		  &M
			 Ssntab
			 .MORE
		    MNT
-------------------------------------------
  Name     #pp  #kp  #ev  MDTP  KPDTP  SSTP
CLEARMEM    2    1    1    25    10     5
-------------------------------------------

		Kpdtab
	10 | &REG   AREG |

		Sstab
		5 | 28

*/

