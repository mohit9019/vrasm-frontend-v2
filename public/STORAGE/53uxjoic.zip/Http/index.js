const http = new XMLHttpRequest();

function apiCall() {

    const url = "http://dummy.restapiexample.com/api/v1/employees";
    http.open("GET", url);

    http.send();

    http.onreadystatechange = (e) => {
        console.log(http.responseText);
        try{
            var data = JSON.parse(http.responseText);
        }
        catch(err)
        {
            console.log(err);
        }
        let html = '<ul>';
        for (let i = 0; i < 5;i++){
            html+=`<li>${data.data[i].employee_name}</li>`;
         }
         html+='</ul>';
        document.getElementById('api').innerHTML = html;
    }
}